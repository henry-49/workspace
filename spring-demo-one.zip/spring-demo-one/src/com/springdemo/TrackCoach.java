package com.springdemo;

public class TrackCoach implements Coach{

	@Override
	public String getDailyWorkOut() {
		
		return "Run a hard 5k";
	}

}
